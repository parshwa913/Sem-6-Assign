//22510064 parshwa herwade
//IOS 5
//11 feb 2025
import Foundation

// 1. Define a Book structure with properties: title, author, price, and yearPublished
// Create an instance of Book and display its details using function displayBook().
struct Book {
    var title: String
    var author: String
    var price: Double
    var yearPublished: Int
    
    func displayBook() {
        print("Question 1:")
        print("Title: \(title), Author: \(author), Price: \(price), Year Published: \(yearPublished)")
    }
}

let myBook = Book(title: "Fundamentals in Swift Programming", author: "Apple", price: 69.69, yearPublished: 2025)
myBook.displayBook()

// 2. Create a Rectangle structure with properties width and height. Add a function calcArea().
struct Rectangle {
    var width: Double
    var height: Double
    
    func calcArea() -> Double {
        return width * height
    }
}

let myRectangle = Rectangle(width: 10.0, height: 5.0)
print("\nQuestion 2:")
print("Rectangle Area: \(myRectangle.calcArea())")

// 3. Create a Temperature structure that has a property celsius. Add an initializer to convert Fahrenheit to Celsius.
struct Temperature {
    var celsius: Double
    
    init(fahrenheit: Double) {
        celsius = (fahrenheit - 32) * 5 / 9
    }
}

let temp = Temperature(fahrenheit: 98.6)
print("\nQuestion 3:")
print("Temperature in Celsius: \(temp.celsius)")

// 4. Define a Student structure with properties name, rollNumber, and marks.
struct Student {
    var name: String
    var rollNumber: Int
    var marks: Double
    
    init() {
        self.name = "John Doe"
        self.rollNumber = 9
        self.marks = 99.0
    }
}

let student = Student()
print("\nQuestion 4:")
print("Name: \(student.name), Roll Number: \(student.rollNumber), Marks: \(student.marks)")

// 5. Define a Smartphone structure with properties: brand, model, storageGB, price.
struct Smartphone {
    var brand: String
    var model: String
    var storageGB: Int
    var price: Double
}

let smartphone = Smartphone(brand: "Apple", model: "iPhone 14", storageGB: 128, price: 999.99)
print("\nQuestion 5:")
print("Smartphone - Brand: \(smartphone.brand), Model: \(smartphone.model), Storage: \(smartphone.storageGB)GB, Price: \(smartphone.price)")

// 6. Create a struct BankAccount with accountHolder and balance. Ensure a minimum balance of ₹500.
struct BankAccount {
    var accountHolder: String
    var balance: Double
    
    init(accountHolder: String, balance: Double) {
        self.accountHolder = accountHolder
        self.balance = balance < 500 ? 500 : balance
    }
}

let account1 = BankAccount(accountHolder: "Alice", balance: 1000)
let account2 = BankAccount(accountHolder: "Bob", balance: 200)
print("\nQuestion 6:")
print("\(account1.accountHolder)'s balance: ₹\(account1.balance)")
print("\(account2.accountHolder)'s balance: ₹\(account2.balance)")

// 7. Create a struct CarDetails with brand, model, year. Default the year to the current year if not provided.
struct CarDetails {
    var brand: String
    var model: String
    var year: Int
    
    init(brand: String, model: String, year: Int? = Calendar.current.component(.year, from: Date())) {
        self.brand = brand
        self.model = model
        self.year = year!
    }
}

let car1 = CarDetails(brand: "Tesla", model: "Model Y")
let car2 = CarDetails(brand: "Toyota", model: "Land Cruiser", year: 2020)
print("\nQuestion 7:")
print("Car 1: \(car1.brand) \(car1.model), Year: \(car1.year)")
print("Car 2: \(car2.brand) \(car2.model), Year: \(car2.year)")

// 8. Define a struct BankAccount with instance methods deposit and withdraw.
struct BankAccountWithMethods {
    var accountHolder: String
    var balance: Double
    
    mutating func deposit(amount: Double) {
        balance += amount
    }
    
    mutating func withdraw(amount: Double) {
        if balance >= amount {
            balance -= amount
        } else {
            print("Insufficient balance")
        }
    }
}

var accountWithMethods = BankAccountWithMethods(accountHolder: "Charlie", balance: 1000)
accountWithMethods.deposit(amount: 200)
accountWithMethods.withdraw(amount: 500)
print("\nQuestion 8:")
print("\(accountWithMethods.accountHolder)'s balance after transactions: ₹\(accountWithMethods.balance)")

// 9. Add mutating methods deposit and withdraw for BankAccount with checking sufficient funds.
var accountMutating = BankAccountWithMethods(accountHolder: "Diana", balance: 800)
accountMutating.deposit(amount: 300)
accountMutating.withdraw(amount: 500)
accountMutating.withdraw(amount: 700) // Insufficient balance
print("\nQuestion 9:")
print("\(accountMutating.accountHolder)'s balance after transactions: ₹\(accountMutating.balance)")

// 10. Define a struct Car with fuelLevel and mileage. Add mutating methods refuel and drive.
struct Car {
    var fuelLevel: Double
    var mileage: Double
    
    mutating func refuel(amount: Double) {
        fuelLevel = min(fuelLevel + amount, 100.0)
    }
    
    mutating func drive(distance: Double) {
        fuelLevel -= distance / mileage
        if fuelLevel < 0 { fuelLevel = 0 }
    }
}

var myCar = Car(fuelLevel: 50, mileage: 15)
myCar.refuel(amount: 30)
myCar.drive(distance: 100)
print("\nQuestion 10:")
print("Car fuel level after refuel and drive: \(myCar.fuelLevel)%")

// 11. Define a struct Employee with name and basicSalary. Add a computed property for netSalary.
struct Employee {
    var name: String
    var basicSalary: Double
    
    var netSalary: Double {
        return basicSalary - (basicSalary * 0.10)
    }
}

let employee = Employee(name: "Emma", basicSalary: 50000)
print("\nQuestion 11:")
print("Employee \(employee.name)'s Net Salary: ₹\(employee.netSalary)")

// 12. Define a struct Speed with metersPerSecond. Add computed properties for km/h and mph.
struct Speed {
    var metersPerSecond: Double
    
    var kmPerHour: Double {
        return metersPerSecond * 3.6
    }
    
    var milesPerHour: Double {
        return metersPerSecond * 2.237
    }
}

let speed = Speed(metersPerSecond: 10)
print("\nQuestion 12:")
print("Speed: \(speed.metersPerSecond) m/s, \(speed.kmPerHour) km/h, \(speed.milesPerHour) mph")

// 13. Define a struct CarSpeed with speed. Use property observers willSet and didSet.
struct CarSpeed {
    var speed: Double {
        willSet {
            print("Current speed: \(speed) km/h, Upcoming speed: \(newValue) km/h")
        }
        didSet {
            if speed > 120 {
                print("Warning: Speed exceeds 120 km/h!")
            }
        }
    }
}

var carSpeed = CarSpeed(speed: 100)
carSpeed.speed = 130 // Exceeds 120 km/h
print("\nQuestion 13:")
print("New Speed: \(carSpeed.speed) km/h")

// 14. Create copy of struct CarSpeed using another instance.
var carSpeedCopy = carSpeed
print("\nQuestion 14:")
print("Car Speed copy: \(carSpeedCopy.speed) km/h")

// 15. Define a struct Circle with a type property and type method for area.
struct Circle {
    static let pi: Double = 3.14159
    
    static func Area(radius: Double) -> Double {
        return pi * radius * radius
    }
}

let area = Circle.Area(radius: 9)
print("\nQuestion 15:")
print("Circle Area: \(area)")

// 16. Define struct Customer with properties name and id.
struct Customer {
    var name: String
    var id: Int
    
    init(name: String, id: Int) {
        self.name = name
        self.id = id
    }
}

let customer = Customer(name: "George", id: 911)
print("\nQuestion 16:")
print("Customer Name: \(customer.name), ID: \(customer.id)")
