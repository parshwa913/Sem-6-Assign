//
//  Account.swift
//  22510094_assign10
//
//  Created by Apple Lab 18 on 16/04/25.
//

import UIKit

class Account: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
