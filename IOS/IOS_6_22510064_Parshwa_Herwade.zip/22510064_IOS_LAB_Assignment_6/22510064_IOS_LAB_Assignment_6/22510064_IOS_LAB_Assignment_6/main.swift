//
//  main.swift
//  Parshwa Herwade 22510064
//  Assignemnt 6
//  Created by Apple Lab 12 on 18/02/25.
//

import Foundation

//Question 1 and Question 2
class Car {
    let brand: String
    let model: String
    let year: Int
    var age: Int
    
    init(brand: String,model:String, year:Int){
        self.brand = brand
        self.model = model
        self.year = year
        age = 2025 - year
    }
    
    func displayDetails(){
        print("----- CAR DETAILS -----")
        print("Car brand : \(brand)")
        print("Car model : \(model)")
        print("Year : \(year)")
        print("(Computed Property) Age : \(age)")
    }
}

let car = Car(brand: "Suzuki", model:"Inova", year: 2020)
car.displayDetails()

//Question 3

class ElectricCar:Car{
    var batteryCapacity:Float
    
    init(brand:String, model:String, year: Int,batteryCapacity:Float){
        self.batteryCapacity = batteryCapacity
        super.init(brand: brand, model: model, year: year)
    }
    
    override func displayDetails() {
        print("----- CAR DETAILS -----")
        print("Car brand : \(brand)")
        print("Car model : \(model)")
        print("Year : \(year)")
        print("(Computed Property) Age : \(age)")
        print("Battery Capacity : \(batteryCapacity)")
    }
}

let electriccar = ElectricCar(brand: "Suzuki", model: "Inova", year: 2020, batteryCapacity: 300.2)
electriccar.displayDetails()

//Question 4
class Animal{
    let name:String
    let age:Int
    
    init(name:String, age:Int){
        self.name = name
        self.age = age
    }
}

class Dog:Animal{
    let breed:String
    
    init(name:String, age:Int, breed:String){
        self.breed = breed
        super.init(name: name, age: age)
    }
}

let dog = Dog(name: "moti", age: 4, breed: "Husky")


//Question 5

class Laptop{
    let brand: String
    let processor: String
    let ramSize:Int
    
    init(brand:String, processor:String, ramSize:Int){
        self.brand = brand
        self.processor = processor
        self.ramSize = ramSize
    }
}

class GamingLaptop:Laptop{
    let graphicsCard:String
    
    init(brand:String, processor:String, ramSize:Int = 8, graphicsCard:String){
        self.graphicsCard = graphicsCard
        super.init(brand:brand, processor:processor, ramSize:ramSize)
    }
    
    func displayLD(){
        print("----- Laptop Details -----")
        print("Brand : \(brand)")
        print("Processor : \(processor)")
        print("Ram size : \(ramSize)")
        print("Graphics Card : \(graphicsCard)")
    }
}

let gaminglaptop = GamingLaptop(brand: "Dell", processor: "Intel i5", graphicsCard: "Nvidia")
gaminglaptop.displayLD()


//Question 6
var numbers:[Int] = [1,-3,50,72,-95,115]
if numbers.contains(72) {
    print("Array contains 72")
}

if !numbers.contains(95) {
    print("Array does not contains 95")
}

//Question 7
var myArray = [Int](repeating: 0, count: 20)
print("Array with all zeros : \(myArray)")

//Question 8
var fruits : [String] = ["banana","apple","watermelon"]

if fruits.isEmpty {
    print("Fruits array is empty")
}else{
    print("Fruits array is not empty")
    print("These are elements in fruits array : \(fruits)")
}

//Question 9
var cricketers: [String] = ["Sachin","Rahul","Rohit","Virat"]
cricketers[0] = "Yuvraj"
cricketers.append("Shubhaman")
cricketers += ["Ravindra","Hardik"]
cricketers.insert("Suresh", at: 5)
cricketers.remove(at: 4)
cricketers.removeLast()
print("Cricketers array : \(cricketers)")

//Question 10
var nameAge = [["Sachin","Virat","Hardik"],[60,47,45]]
print("Name and age of first element : \(nameAge[0][0]) , \(nameAge[1][0])")

//Question 11
var scores = ["Sachin":50000, "Hardik":4000, "Ravindra":8000]
print(scores)


//Question 12
scores["Virat"] = 25000
let oldScore = scores.updateValue(9000, forKey: "Hardik")
print(scores)

//Question 13
let removedValue = scores.removeValue(forKey:"Sachine")
print("Score of removed element : \(removedValue ?? 0)")

//Question 14
let players = Array(scores.keys)
let points = Array(scores.values)

print("Players array : \(players)")
print("Points array : \(points)")

//Question 15
var cities:[String] = ["Sangli","Kolhapur","Pune","Mumbai","Solapur"]
for i in cities {
    print(i)
}

//Question 16
var fact = 1
for i in 1...5{
    fact = fact*i
}
print("Factorial of 5 is \(fact)")

//Question 17
let vehicles = ["unicycle":1,"bicycle":2,"tricycle":3,"quad bike":4]

for (i,j) in vehicles{
    print("\(i) has \(j) wheels")
}

//Question 18
var num: Int
num = Int(readLine()!)!
var count = 2
var i = 2
while count<3 || i<num{
    if num%i == 0{
        count = count+1
    }
}
if(count > 2){
    print("\(num) is not prime")
}else{
    print("\(num) is prime")
}

//Question 19
var number:Int
number = Int(readLine()!)!
var reminder:Int
var reverse = 1
var original = number
while number != 0{
    reminder = number%10
    reverse = reverse * 10 + reminder
    number /= 10
}

//Question 20
var myNumber = 407
var sum = 0
var n = myNumber

while(n != 0){
    let rem = n%10
    sum = sum*(rem*rem*rem)
    n = n/10
}
if(sum == myNumber){
    print("Number is armstrong")
}
else {
    print("Number is not armstrong")
}

