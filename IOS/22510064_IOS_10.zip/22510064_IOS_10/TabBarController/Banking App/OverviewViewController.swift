//
//  OverviewViewController.swift
//  Banking App
//
//  Created by Apple Lab 29 on 16/04/25.
//
import UIKit

import Foundation
class OverviewViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Overview"

        let balanceLabel = UILabel()
        balanceLabel.text = "Balance: 50,00,000"
        balanceLabel.font = UIFont.boldSystemFont(ofSize: 24)
        balanceLabel.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(balanceLabel)
        NSLayoutConstraint.activate([
            balanceLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            balanceLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
}
