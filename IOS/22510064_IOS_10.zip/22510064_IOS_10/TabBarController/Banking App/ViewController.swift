//
//  ViewController.swift
//  Banking App
//
//  Created by Apple Lab 29 on 16/04/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

