//
//  MainTabBarController.swift
//  Banking App
//
//  Created by Apple Lab 29 on 16/04/25.
//
import UIKit

import Foundation
class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let overviewVC = OverviewViewController()
        overviewVC.tabBarItem = UITabBarItem(title: "Overview", image: UIImage(systemName: "rectangle.stack"), tag: 0)

        let transactionsVC = TransactionsViewController()
        transactionsVC.tabBarItem = UITabBarItem(title: "Transactions", image: UIImage(systemName: "list.bullet.rectangle"), tag: 1)
        transactionsVC.tabBarItem.badgeValue = "3" 

        let transfersVC = TransfersViewController()
        transfersVC.tabBarItem = UITabBarItem(title: "Transfers", image: UIImage(systemName: "arrow.right.arrow.left"), tag: 2)

        let settingsVC = SettingsViewController()
        settingsVC.tabBarItem = UITabBarItem(title: "Settings", image: UIImage(systemName: "gearshape"), tag: 3)

        viewControllers = [
            UINavigationController(rootViewController: overviewVC),
            UINavigationController(rootViewController: transactionsVC),
            UINavigationController(rootViewController: transfersVC),
            UINavigationController(rootViewController: settingsVC)
        ]
    }
}
