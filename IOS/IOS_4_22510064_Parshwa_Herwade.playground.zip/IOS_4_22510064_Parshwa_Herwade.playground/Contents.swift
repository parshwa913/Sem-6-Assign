//IOS 4
// FEBRUARY 4TH 2025
// 22510064 PARSHWA HERWADE

import Foundation

// 1. Print name and age using string interpolation.
let name = "Alice"
let age = 25
print("1. \(name) is \(age) years old.")

// 2. Print sum of two numbers using string interpolation.
let num1 = 10
let num2 = 5
print("2. The sum of \(num1) and \(num2) is \(num1 + num2).")

// 3. Print length of a string.
let text = "Hello, Swift!"
print("3. The length of the string is \(text.count).")

// 4. Convert string to uppercase and lowercase.
let message = "Hello, Swift!"
let uppercased = message.uppercased()
let lowercased = message.lowercased()
print("4. Uppercase: \(uppercased)")
print("4. Lowercase: \(lowercased)")

// 5. Check if a string is empty.
let text2 = ""
if text2.isEmpty {
    print("5. String is empty")
} else {
    print("5. String is not empty")
}

// 6. Concatenate two strings.
let firstName = "Alice"
let lastName = "Johnson"
let fullName = firstName + " " + lastName
print("6. \(fullName)")

// 7. Check if a string starts with "Swift".
let word = "SwiftLanguage"
let startsWithSwift = word.hasPrefix("Swift")
print("7. \(startsWithSwift)")

// 8. Extract domain extension from website.
let website = "www.example.com"
let domainExtension = String(website.suffix(4))
print("8. Domain extension: \(domainExtension)")

// 9. Check if "brown" is present in the text.
let text3 = "The quick brown fox"
let containsBrown = text3.contains("brown")
print("9. \(containsBrown)")

// 10. Compare two strings case-sensitively.
let str1 = "Hello"
let str2 = "hello"
let areEqual = str1 == str2
print("10. Case-sensitive comparison: \(areEqual)")

// 11. Compare two strings ignoring case.
let areEqualIgnoringCase = str1.lowercased() == str2.lowercased()
print("11. Case-insensitive comparison: \(areEqualIgnoringCase)")

// 12. Check if today is weekend (Saturday or Sunday).
func isWeekend() -> Bool {
    let today = Calendar.current.component(.weekday, from: Date())
    return today == 7 || today == 1
}
print("12. Is it weekend? \(isWeekend())")

// 13. Check if a number is even.
func isEven(number: Int) -> Bool {
    return number % 2 == 0
}
print("13. Is 4 even? \(isEven(number: 4))")
print("13. Is 7 even? \(isEven(number: 7))")

// 14. Convert Celsius to Fahrenheit.
func celsiusToFahrenheit(celsius: Double) -> Double {
    return (celsius * 9/5) + 32
}
print("14. 25°C in Fahrenheit: \(celsiusToFahrenheit(celsius: 25))")

// 15. Calculate power of a number (default exponent = 2).
func power(base: Int, exponent: Int = 2) -> Int {
    return Int(pow(Double(base), Double(exponent)))
}
print("15. Power of 3 (default exponent): \(power(base: 3))")
print("15. Power of 2 with exponent 3: \(power(base: 2, exponent: 3))")

// 16. Calculate area of a rectangle.
func calculateArea(of length: Double, and width: Double) -> Double {
    return length * width
}
print("16. Area of rectangle (10 x 5): \(calculateArea(of: 10, and: 5))")

// 17. Greet a person by name.
func greet(person name: String) {
    print("17. Hello, \(name)!")
}
greet(person: "Alice")

// 18. Print a message multiple times.
func repeatMessage(_ message: String, _ times: Int) {
    for _ in 1...times {
        print("18. \(message)")
    }
}
repeatMessage("Swift", 3)

// 19. Return the larger of two numbers.
func maxOfTwo(a: Int, b: Int) -> Int {
    return a > b ? a : b
}
print("19. Larger number between 8 and 12: \(maxOfTwo(a: 8, b: 12))")

// 20. Calculate factorial of a number.
func factorial(n: Int) -> Int {
    if n == 0 || n == 1 {
        return 1
    }
    return n * factorial(n: n - 1)
}
print("20. Factorial of 5: \(factorial(n: 5))")
