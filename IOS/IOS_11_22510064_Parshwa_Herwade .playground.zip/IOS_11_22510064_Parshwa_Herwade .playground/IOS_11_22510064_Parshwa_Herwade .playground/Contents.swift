//22510064 parshwa herwade
//IOS 11
//22 feb 2025
import Foundation

// 1. calculateArea with guard
func calculateArea(x: Double, y: Double) -> Double? {
    guard x > 0, y > 0 else {
        return nil
    }
    return x * y
}

// Calls for Q1
if let area1 = calculateArea(x: 5, y: 3) {
    print("[Q1] Area is \(area1)")    // Area is 15.0
} else {
    print("[Q1] Invalid dimensions")
}
if let area2 = calculateArea(x: -2, y: 4) {
    print("[Q1] Area is \(area2)")
} else {
    print("[Q1] Invalid dimensions")
}

// 2. add two optional Ints with guard
func add(_ a: Int?, _ b: Int?) -> Int? {
    guard let a = a, let b = b else {
        return nil
    }
    return a + b
}

// Calls for Q2
if let sum1 = add(10, 20) {
    print("[Q2] Sum is \(sum1)")    // Sum is 30
} else {
    print("[Q2] One or both values missing")
}
if let sum2 = add(5, nil) {
    print("[Q2] Sum is \(sum2)")
} else {
    print("[Q2] One or both values missing")
}

// 3. createUser unwrapping three text fields
struct UserQ3 {
    var firstName: String
    var lastName: String
    var age: String
}
let firstNameTextField = UITextField()
let lastNameTextField = UITextField()
let ageTextField = UITextField()
firstNameTextField.text = "Jonathan"
lastNameTextField.text = "Sanders"
ageTextField.text = "28"
func createUser() -> UserQ3? {
    guard
        let first = firstNameTextField.text,
        let last = lastNameTextField.text,
        let age = ageTextField.text
    else {
        return nil
    }
    return UserQ3(firstName: first, lastName: last, age: age)
}

// 4. Call createUser and print
if let user = createUser() {
    print("[Q4] User: \(user.firstName) \(user.lastName), age \(user.age)")
} else {
    print("[Q4] Failed to create user")
}

// 5–7. Workout struct with failable initializer
typealias Seconds = Double
struct Workout {
    let startTime: Seconds
    let endTime: Seconds

    init?(startTime: Seconds, endTime: Seconds) {
        guard endTime - startTime > 10 else {
            return nil
        }
        self.startTime = startTime
        self.endTime = endTime
    }
}
// Examples for Q5–7
if let w1 = Workout(startTime: 100, endTime: 120) {
    print("[Q5-7] Workout valid: \(w1.startTime) to \(w1.endTime)")
} else {
    print("[Q5-7] Workout too short")
}
if let w2 = Workout(startTime: 200, endTime: 205) {
    print("[Q5-7] Workout valid: \(w2.startTime) to \(w2.endTime)")
} else {
    print("[Q5-7] Workout too short")
}

// 8. logFood unwrapping name & calories
struct Food {
    var name: String
    var calories: Int
}
let foodTextField = UITextField()
let caloriesTextField = UITextField()
foodTextField.text = "Banana"
caloriesTextField.text = "23"
func logFood() -> Food? {
    guard
        let name = foodTextField.text,
        let caloriesText = caloriesTextField.text,
        let calories = Int(caloriesText)
    else {
        return nil
    }
    return Food(name: name, calories: calories)
}
// 9. Call logFood and print
if let item = logFood() {
    print("[Q9] Logged \(item.name) with \(item.calories) calories")
} else {
    print("[Q9] Failed to log food")
}
// Simulate invalid calories
caloriesTextField.text = "twenty-three"
if let item2 = logFood() {
    print("[Q9] Logged \(item2.name) with \(item2.calories) calories")
} else {
    print("[Q9] Failed to log food")
}

// 10. Scope error example for foo
for _ in 0..<10 {
    let foo = 55
    print("[Q10] The value of foo is \(foo)")
}
// Foo is out of scope here
// print("[Q10] The value of foo is \(foo)") // Error: foo is undefined

// 11. x in outer scope vs foo
var x = 10
for _ in 0..<10 {
    x += 1
    print("[Q11] The value of x is \(x)")
}
print("[Q11] The final value of x is \(x)")

// 12. greeting with shadowing
func greeting(greeting: String?, name: String) {
    if let greeting = greeting {
        print("[Q12] \(greeting), \(name).")
    } else {
        print("[Q12] Hello, \(name).")
    }
}
// Calls Q12
greeting(greeting: "Hi there", name: "Sara")
greeting(greeting: nil, name: "Alex")

// 13. Car class with initializer
class Car {
    var make: String
    var model: String
    var year: Int

    init(make: String, model: String, year: Int) {
        self.make = make
        self.model = model
        self.year = year
    }
}
let myCar = Car(make: "Toyota", model: "Corolla", year: 2020)
print("[Q13] My car: \(myCar.year) \(myCar.make) \(myCar.model)")

// 14. User struct and instances
struct UserQ14 {
    var name: String
    var stepsToday: Int
}
let stepMaster    = UserQ14(name: "StepMaster",    stepsToday: 8394)
let activeSitter  = UserQ14(name: "ActiveSitter",  stepsToday: 9132)
let monsterWalker = UserQ14(name: "MonsterWalker", stepsToday: 7193)
let competitors = [stepMaster, activeSitter, monsterWalker]

// 15. getWinner fix and call
func getWinner(competitors: [UserQ14]) -> UserQ14? {
    var topCompetitor: UserQ14?
    for competitor in competitors {
        if let currentTop = topCompetitor {
            if competitor.stepsToday > currentTop.stepsToday {
                topCompetitor = competitor
            }
        } else {
            topCompetitor = competitor
        }
    }
    return topCompetitor
}
if let winner = getWinner(competitors: competitors) {
    print("[Q15] Winner is \(winner.name)")
}

// 16. Memberwise initializer for UserQ14
extension UserQ14 {
    init(name: String, stepsToday: Int) {
        self.name = name
        self.stepsToday = stepsToday
    }
}

// 17. Failable initializer with shadowing for UserQ14
extension UserQ14 {
    init?(name: String?, stepsToday: Int?) {
        guard let name = name, let steps = stepsToday else {
            return nil
        }
        self.name = name
        self.stepsToday = steps
    }
}
// Example Q17
if let u = UserQ14(name: "Chris", stepsToday: 5000) {
    print("[Q17] Created user \(u.name) with \(u.stepsToday) steps")
}
if let u2 = UserQ14(name: nil, stepsToday: 2000) {
    print(u2)
} else {
    print("[Q17] Failed to create user")
}

// 18. Suit enum
enum Suit {
    case clubs, spades, diamonds, hearts
}

// 19. cardInHand = .hearts
var cardInHand = Suit.hearts
print("[Q19] cardInHand: \(cardInHand)")

// 20. change to .spades
cardInHand = .spades
print("[Q20] cardInHand: \(cardInHand)")

// 21. getFortune switch on Suit
func getFortune(cardSuit: Suit) {
    switch cardSuit {
    case .clubs:
        print("[Q21] You will find a loyal friend soon.")
    case .spades:
        print("[Q21] A challenge approaches—face it bravely.")
    case .diamonds:
        print("[Q21] Wealth may find its way to you.")
    case .hearts:
        print("[Q21] Love is on the horizon.")
    }
}
// Calls Q21
getFortune(cardSuit: .clubs)
getFortune(cardSuit: .diamonds)
getFortune(cardSuit: .hearts)

// 22. Card struct with Int value
struct CardQ22 {
    var suit: Suit
    var value: Int
}
let card1 = CardQ22(suit: .hearts, value: 7)
print("[Q22] Card: \(card1.value) of \(card1.suit)")

// 23. Card struct with Value enum
struct CardQ23 {
    enum Value {
        case ace, two, three, four, five, six, seven, eight, nine, ten, jack, queen, king
    }
    var suit: Suit
    var value: Value
}
let aceOfSpades   = CardQ23(suit: .spades, value: .ace)
let queenOfHearts = CardQ23(suit: .hearts, value: .queen)
func describe(card: CardQ23) {
    print("[Q23] Card is \(card.value) of \(card.suit)")
}
describe(card: aceOfSpades)
describe(card: queenOfHearts)
