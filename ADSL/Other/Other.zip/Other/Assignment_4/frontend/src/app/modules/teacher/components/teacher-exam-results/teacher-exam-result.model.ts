export interface ExamResult {
  status: string;
  total_score: number;
  user_id: number;
}
