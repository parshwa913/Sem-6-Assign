export interface AssignedStudent {
  id: number;
  username: string;
}
